# Python API Examples
See the [OpenPose Python API doc](../../doc/03_python_api.md) for more details on this folder.

This folder provides examples to the basic OpenPose Python API. The analogous C++ API is exposed in [examples/tutorial_api_cpp/](../tutorial_api_cpp/).
