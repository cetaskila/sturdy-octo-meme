// Temporarily, all the code is located in
// src/openpose/unity/unityBinding.cpp
// TODO: Move functionality from unityBinding.cpp to this class
