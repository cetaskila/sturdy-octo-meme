#ifndef OPENPOSE_GPU_HEADERS_HPP
#define OPENPOSE_GPU_HEADERS_HPP

// gpu module
#include <openpose/gpu/cuda.hpp>
#include <openpose/gpu/enumClasses.hpp>
#include <openpose/gpu/gpu.hpp>

#endif // OPENPOSE_GPU_HEADERS_HPP
