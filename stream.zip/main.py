import sys,client as B,argparse as C
if __name__=='__main__':A=C.ArgumentParser();A.add_argument('-secret',required=True,help='Secret value');D=A.parse_args();E=D.secret;sys.argv=['main.py',E];B.y()